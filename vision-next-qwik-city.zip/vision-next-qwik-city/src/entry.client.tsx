import { render } from '@builder.io/qwik';
import { Root } from './root';

render(document, <Root />);
